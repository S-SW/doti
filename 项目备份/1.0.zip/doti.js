// 核心状态管理
let originalQuestions = [];
let currentQuestions = [];
let wrongQuestions = [];
let favQuestions = []; // 收藏题库数组
let currentIndex = 0;
let isSingleMode = true;
let isWrongMode = false;
let isFavMode = false; // 是否处于收藏夹刷题模式
let fileSignature = "";

// 答题痕迹持久化容器
let userHistoryTracks = {};
const LETTER_ARR = ["A", "B", "C", "D"];

// 初始化读取本地缓存
try {
  const savedWrong = localStorage.getItem("quiz_wrong_questions");
  if (savedWrong) {
    wrongQuestions = JSON.parse(savedWrong);
    document.getElementById("wrongCount").innerText = wrongQuestions.length;
  }
  const savedFav = localStorage.getItem("quiz_fav_questions");
  if (savedFav) {
    favQuestions = JSON.parse(savedFav);
    document.getElementById("favCount").innerText = favQuestions.length;
  }
  const savedTracks = localStorage.getItem("quiz_user_tracks");
  if (savedTracks) userHistoryTracks = JSON.parse(savedTracks);
} catch (e) {
  console.error(e);
}

// 1. 悬浮窗收起展开交互控制（核心改动：收起时全屏绝对居中）
const sidebar = document.getElementById("sidebarPanel");
const toggleSidebarBtn = document.getElementById("toggleSidebarBtn");

toggleSidebarBtn.addEventListener("click", () => {
  sidebar.classList.toggle("collapsed");
  if (sidebar.classList.contains("collapsed")) {
    toggleSidebarBtn.innerText = "◀ 展开面板";
    document.body.style.paddingLeft = "40px";
    document.body.style.paddingRight = "40px";
  } else {
    toggleSidebarBtn.innerText = "▶ 收起面板";
    document.body.style.paddingLeft = "310px";
    document.body.style.paddingRight = "310px";
  }
});

// 2. 主题切换
document.getElementById("themeBtn").addEventListener("click", () => {
  const body = document.body;
  if (body.getAttribute("data-theme") === "light") {
    body.removeAttribute("data-theme");
    document.getElementById("themeBtn").innerText = "☀️ 白天模式";
  } else {
    body.setAttribute("data-theme", "light");
    document.getElementById("themeBtn").innerText = "✨ 夜间模式";
  }
});

// 3. 切换单题/整卷模式
document.getElementById("toggleModeBtn").addEventListener("click", () => {
  let list = isWrongMode
    ? wrongQuestions
    : isFavMode
      ? favQuestions
      : currentQuestions;
  if (list.length === 0) return;
  isSingleMode = !isSingleMode;

  const btn = document.getElementById("toggleModeBtn");
  const nav = document.getElementById("navPanel");

  if (isSingleMode) {
    btn.classList.remove("active");
    btn.innerText = "切换整卷模式";
    nav.style.display = "flex";
  } else {
    btn.classList.add("active");
    btn.innerText = "切换单题模式";
    nav.style.display = "none";
  }
  refreshDisplay();
});

// 4. 书签位置保存
document.getElementById("setBookmarkBtn").addEventListener("click", () => {
  if (!fileSignature) return alert("请先上传一个题库再做标记！");
  localStorage.setItem("bookmark_" + fileSignature, currentIndex);
  document.getElementById("bookmarkTip").innerText =
    `第 ${currentIndex + 1} 题`;
  alert(
    `已成功标记当前位置（第 ${currentIndex + 1} 题），下次导入该文件将自动直达！`,
  );
});

// 5. 进入/退出错题本模式
const toggleWrongModeBtn = document.getElementById("toggleWrongModeBtn");
toggleWrongModeBtn.addEventListener("click", () => {
  if (!isWrongMode && wrongQuestions.length === 0)
    return alert("当前错题本为空！");

  isWrongMode = !isWrongMode;
  isFavMode = false; // 互斥
  currentIndex = 0;

  toggleFavModeBtn.classList.remove("active");
  toggleFavModeBtn.innerHTML = `进入收藏夹 (<span id="favCount">${favQuestions.length}</span>)`;

  if (isWrongMode) {
    toggleWrongModeBtn.classList.add("active");
    toggleWrongModeBtn.innerHTML = "返回主题库";
    document.getElementById("exportWrongBtn").style.display = "inline-block";
    document.getElementById("clearWrongBtn").style.display = "inline-block";
  } else {
    toggleWrongModeBtn.classList.remove("active");
    toggleWrongModeBtn.innerHTML = `进入错题本 (<span id="wrongCount">${wrongQuestions.length}</span>)`;
    document.getElementById("exportWrongBtn").style.display = "none";
    document.getElementById("clearWrongBtn").style.display = "none";
  }
  refreshDisplay();
});

// 6. 清空/导出错题
document.getElementById("clearWrongBtn").addEventListener("click", () => {
  if (!confirm("确定要清空所有保存的错题吗？")) return;
  wrongQuestions = [];
  localStorage.setItem("quiz_wrong_questions", JSON.stringify([]));
  document.getElementById("wrongCount").innerText = "0";
  isWrongMode = false;
  toggleWrongModeBtn.classList.remove("active");
  toggleWrongModeBtn.innerHTML = `进入错题本 (0)`;
  document.getElementById("exportWrongBtn").style.display = "none";
  document.getElementById("clearWrongBtn").style.display = "none";
  refreshDisplay();
});

document.getElementById("exportWrongBtn").addEventListener("click", () => {
  if (wrongQuestions.length === 0) return;
  let outputLines = wrongQuestions.map((q) => q.rawLine);
  let blob = new Blob([outputLines.join("\r\n")], {
    type: "text/plain;charset=utf-8",
  });
  let url = URL.createObjectURL(blob);
  let a = document.createElement("a");
  a.href = url;
  a.download = "错题本.txt";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
});

// 7. 进入/退出收藏夹模式
const toggleFavModeBtn = document.getElementById("toggleFavModeBtn");
toggleFavModeBtn.addEventListener("click", () => {
  if (!isFavMode && favQuestions.length === 0)
    return alert("当前收藏夹为空，快去主页题目中收藏吧！");

  isFavMode = !isFavMode;
  isWrongMode = false; // 互斥
  currentIndex = 0;

  // 还原错题按钮状态
  toggleWrongModeBtn.classList.remove("active");
  toggleWrongModeBtn.innerHTML = `进入错题本 (<span id="wrongCount">${wrongQuestions.length}</span>)`;
  document.getElementById("exportWrongBtn").style.display = "none";
  document.getElementById("clearWrongBtn").style.display = "none";

  if (isFavMode) {
    toggleFavModeBtn.classList.add("active");
    toggleFavModeBtn.innerHTML = "返回主题库";
  } else {
    toggleFavModeBtn.classList.remove("active");
    toggleFavModeBtn.innerHTML = `进入收藏夹 (<span id="favCount">${favQuestions.length}</span>)`;
  }
  refreshDisplay();
});

// 8. 收藏与取消收藏切换引擎（核心改动：支持收藏夹内重新作答）
function toggleFavorite(qId, btnObj) {
  let list = isWrongMode
    ? wrongQuestions
    : isFavMode
      ? favQuestions
      : currentQuestions;
  let qObj = list.find((item) => item.id === qId);
  if (!qObj) return;

  let favIdx = favQuestions.findIndex((item) => item.id === qId);

  if (favIdx === -1) {
    // 收藏此题：克隆一份放入收藏夹，并**重置此题在收藏夹的专属答题痕迹**，保证可以重新做！
    let clonedQuestion = JSON.parse(JSON.stringify(qObj));
    favQuestions.push(clonedQuestion);
    btnObj.innerText = "★ 已收藏";
    btnObj.style.backgroundColor = "#ecc94b";
    btnObj.style.color = "#1a202c";
  } else {
    // 取消收藏
    favQuestions.splice(favIdx, 1);
    btnObj.innerText = "☆ 收藏此题";
    btnObj.style.backgroundColor = "var(--option-bg)";
    btnObj.style.color = "var(--text-color)";

    // 如果在收藏夹模式里移除了题目，实时控频题号
    if (isFavMode && currentIndex >= favQuestions.length && currentIndex > 0) {
      currentIndex--;
    }
  }

  localStorage.setItem("quiz_fav_questions", JSON.stringify(favQuestions));
  document.getElementById("favCount").innerText = favQuestions.length;

  // 同步刷新
  let currentList = isWrongMode
    ? wrongQuestions
    : isFavMode
      ? favQuestions
      : currentQuestions;
  buildAnswerCardMatrix(currentList);
  if (isFavMode) refreshDisplay();
}

// 9. 题库解析与导入
document.getElementById("fileInput").addEventListener("change", function (e) {
  const file = e.target.files[0];
  if (!file) return;

  document.getElementById("fileNameDisplay").innerText = file.name;
  fileSignature = btoa(encodeURIComponent(file.name + "_" + file.size));

  const reader = new FileReader();
  reader.onload = function (e) {
    const lines = e.target.result.split(/\r?\n/);
    originalQuestions = [];
    let validIndex = 0;

    lines.forEach((line) => {
      let trimmedLine = line.trim();
      if (!trimmedLine) return;

      const parts = trimmedLine.split("|").map((item) => item.trim());
      if (parts.length < 3) return;

      const q = parts[0];
      const ans = parts[parts.length - 1];
      const optionsParts = parts.slice(1, parts.length - 1);

      let typeBadge = "";
      let isMultiple = false;

      if (
        ans === "A" ||
        ans === "B" ||
        ans === "C" ||
        ans === "D" ||
        ans === "正确" ||
        ans === "错误"
      ) {
        if (
          optionsParts[1] === "错误" ||
          optionsParts[1] === "错" ||
          optionsParts.length === 2
        ) {
          typeBadge =
            '<span style="background:#3182ce;color:white;padding:2px 6px;border-radius:4px;font-size:12px;margin-right:6px;">判断题</span>';
        } else if (optionsParts.length > 2) {
          typeBadge =
            '<span style="background:#4cbd50;color:white;padding:2px 6px;border-radius:4px;font-size:12px;margin-right:6px;">单选题</span>';
        } else {
          typeBadge =
            '<span style="background:#f0932b;color:white;padding:2px 6px;border-radius:4px;font-size:12px;margin-right:6px;">填空题</span>';
        }
      } else if (ans.length > 1 && /^[A-D]+$/.test(ans)) {
        isMultiple = true;
        typeBadge =
          '<span style="background:#e056fd;color:white;padding:2px 6px;border-radius:4px;font-size:12px;margin-right:6px;">多选题</span>';
      } else {
        typeBadge =
          '<span style="background:#f0932b;color:white;padding:2px 6px;border-radius:4px;font-size:12px;margin-right:6px;">填空题</span>';
      }

      let mappedOptions = optionsParts
        .map((optText, index) => {
          if (!optText) return null;
          let showText = optText;
          if (
            !optText.startsWith("A") &&
            !optText.startsWith("B") &&
            !optText.startsWith("C") &&
            !optText.startsWith("D") &&
            index < 4
          ) {
            showText = `${LETTER_ARR[index]}. ${optText}`;
          }
          return {
            text: showText,
            originalChar: LETTER_ARR[index] || "A",
          };
        })
        .filter((item) => item !== null);

      // 打乱每题选项
      for (let i = mappedOptions.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [mappedOptions[i], mappedOptions[j]] = [
          mappedOptions[j],
          mappedOptions[i],
        ];
      }

      originalQuestions.push({
        q,
        options: mappedOptions,
        ans,
        id: "q-" + fileSignature + "-" + validIndex,
        typeBadge,
        isMultiple,
        rawLine: trimmedLine,
      });
      validIndex++;
    });

    currentQuestions = JSON.parse(JSON.stringify(originalQuestions));
    isWrongMode = false;
    isFavMode = false;

    // 书签恢复
    const savedIndex = localStorage.getItem("bookmark_" + fileSignature);
    if (savedIndex !== null && parseInt(savedIndex) < currentQuestions.length) {
      currentIndex = parseInt(savedIndex);
      document.getElementById("bookmarkTip").innerText =
        `第 ${currentIndex + 1} 题`;
    } else {
      currentIndex = 0;
      document.getElementById("bookmarkTip").innerText = "未标记";
    }

    refreshDisplay();
  };
  reader.readAsText(file, "UTF-8");
});

// 10. 统一视图刷新控制
function refreshDisplay() {
  let list = isWrongMode
    ? wrongQuestions
    : isFavMode
      ? favQuestions
      : currentQuestions;
  const nav = document.getElementById("navPanel");

  if (list.length === 0) {
    document.getElementById("quizContainer").innerHTML =
      `<div style="text-align:center;color:#718096;padding:40px;">暂无题目数据，请导入题库。</div>`;
    nav.style.display = "none";
    document.getElementById("boxGrid").innerHTML = "";
    updateProgress();
    return;
  }

  if (isSingleMode) {
    nav.style.display = "flex";
    document.getElementById("quizContainer").innerHTML = buildQuestionHtml(
      list[currentIndex],
      currentIndex,
    );
    document.getElementById("prevBtn").disabled = currentIndex === 0;
    document.getElementById("nextBtn").disabled =
      currentIndex === list.length - 1;
  } else {
    nav.style.display = "none";
    document.getElementById("quizContainer").innerHTML = list
      .map((q, i) => buildQuestionHtml(q, i))
      .join("");
  }

  restoreAnswering痕迹(list);
  buildAnswerCardMatrix(list);
  updateProgress();
}

// 11. 构建题目卡片（融入收藏高亮效果）
function buildQuestionHtml(qObj, displayIdx) {
  let optionsHtml = `<ul class="options" data-id="${qObj.id}" data-ans="${qObj.ans}" data-multiple="${qObj.isMultiple}">`;

  qObj.options.forEach((opt) => {
    optionsHtml += `<li data-char="${opt.originalChar}" onclick="check(this, '${opt.originalChar}')">${opt.text}</li>`;
  });
  optionsHtml += "</ul>";

  if (qObj.isMultiple) {
    optionsHtml += `<button class="nav-btn submit-mult-btn" style="margin-top:12px; border-radius:6px; padding:6px 15px; font-size:14px;" onclick="submitMultiple(this)">确认选择</button>`;
  }

  // 检测是否收藏
  let isFav = favQuestions.some((item) => item.id === qObj.id);
  let favStyle = isFav ? "background-color:#ecc94b; color:#1a202c;" : "";
  let favText = isFav ? "★ 已收藏" : "☆ 收藏此题";

  return `
        <div class="question" id="box-${qObj.id}" data-global-idx="${displayIdx}">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px;">
              <p style="margin:0; flex:1;">${qObj.typeBadge}<span class="display-idx">${displayIdx + 1}</span>. ${qObj.q}</p>
              <button class="action-btn" style="width:auto; padding:4px 10px; font-size:12px; margin-left:10px; flex-shrink:0; ${favStyle}" onclick="toggleFavorite('${qObj.id}', this)">${favText}</button>
            </div>
            ${optionsHtml}
        </div>
      `;
}

// 12. 恢复红绿作答记录痕迹
function restoreAnswering痕迹(list) {
  list.forEach((qObj) => {
    let track = userHistoryTracks[qObj.id];
    if (!track) return;

    let qBox = document.getElementById(`box-${qObj.id}`);
    if (!qBox) return;

    let ul = qBox.querySelector(".options");
    ul.classList.add("answered");

    let btn = qBox.querySelector(".submit-mult-btn");
    if (btn) btn.style.display = "none";

    Array.from(ul.children).forEach((li) => {
      let itemChar = li.getAttribute("data-char");
      if (qObj.isMultiple) {
        if (
          track.userChoice.includes(itemChar) &&
          !qObj.ans.includes(itemChar)
        ) {
          li.classList.add("wrong");
        } else if (qObj.ans.includes(itemChar)) {
          li.classList.add("correct");
        }
      } else {
        if (track.userChoice.includes(itemChar)) {
          li.classList.add(track.status === "correct" ? "correct" : "wrong");
        } else if (itemChar === qObj.ans) {
          li.classList.add("correct");
        }
      }
    });
  });
}

// 13. 动态构造分题型答题卡矩阵看板
function buildAnswerCardMatrix(list) {
  const grid = document.getElementById("boxGrid");
  grid.innerHTML = "";

  let correctCount = 0,
    wrongCount = 0,
    unsolvedCount = 0;

  const categorized = { 单选题: [], 多选题: [], 判断题: [], 填空题: [] };
  list.forEach((qObj, idx) => {
    let typeStr = "单选题";
    if (qObj.typeBadge.includes("多选题")) typeStr = "多选题";
    else if (qObj.typeBadge.includes("判断题")) typeStr = "判断题";
    else if (qObj.typeBadge.includes("填空题")) typeStr = "填空题";
    categorized[typeStr].push({ qObj, realIdx: idx });
  });

  for (const [typeName, items] of Object.entries(categorized)) {
    if (items.length === 0) continue;

    const sectionTitle = document.createElement("div");
    sectionTitle.style.cssText =
      "grid-column: span 5; font-size: 12px; font-weight: bold; color: var(--accent-color); margin: 10px 0 4px 0; border-left: 3px solid var(--accent-color); padding-left: 6px;";
    sectionTitle.innerText = `${typeName} (${items.length})`;
    grid.appendChild(sectionTitle);

    items.forEach(({ qObj, realIdx }) => {
      const box = document.createElement("div");
      box.className = "grid-box";
      box.innerText = realIdx + 1;

      if (isSingleMode && realIdx === currentIndex) {
        box.classList.add("current-view");
      }

      // 判定收藏外圈高亮金边
      let hasFav = favQuestions.some((item) => item.id === qObj.id);
      if (hasFav) {
        box.style.border = "2px solid #ecc94b";
      }

      let track = userHistoryTracks[qObj.id];
      if (track) {
        if (track.status === "correct") {
          box.classList.add("status-correct");
          correctCount++;
        } else {
          box.classList.add("status-wrong");
          wrongCount++;
        }
      } else {
        unsolvedCount++;
      }

      box.addEventListener("click", () => {
        if (isSingleMode) {
          currentIndex = realIdx;
          refreshDisplay();
        } else {
          document
            .getElementById(`box-${qObj.id}`)
            .scrollIntoView({ behavior: "smooth", block: "center" });
        }
      });
      grid.appendChild(box);
    });
  }

  document.getElementById("statCorrect").innerText = correctCount;
  document.getElementById("statWrong").innerText = wrongCount;
  document.getElementById("statUnsolved").innerText = unsolvedCount;
}

function updateProgress() {
  const text = document.getElementById("progressText");
  let list = isWrongMode
    ? wrongQuestions
    : isFavMode
      ? favQuestions
      : currentQuestions;
  let prefix = "【主题库】";
  if (isWrongMode) prefix = "【错题本】";
  if (isFavMode) prefix = "【收藏夹】";

  if (list.length === 0) {
    text.innerText = `${prefix} 空空如也~`;
    return;
  }
  text.innerText = isSingleMode
    ? `${prefix} 第 ${currentIndex + 1} 题 / 共 ${list.length} 题`
    : `${prefix} 整卷加载：共 ${list.length} 题`;
}

function addToWrongList(qId) {
  let fullQuestion = originalQuestions.find((item) => item.id === qId);
  if (!fullQuestion && isWrongMode)
    fullQuestion = wrongQuestions.find((item) => item.id === qId);
  if (!fullQuestion && isFavMode)
    fullQuestion = favQuestions.find((item) => item.id === qId);

  if (fullQuestion) {
    let exists = wrongQuestions.some(
      (item) => item.rawLine === fullQuestion.rawLine,
    );
    if (!exists) {
      wrongQuestions.push(fullQuestion);
      localStorage.setItem(
        "quiz_wrong_questions",
        JSON.stringify(wrongQuestions),
      );
      document.getElementById("wrongCount").innerText = wrongQuestions.length;
    }
  }
}

// 14. 判题引擎（支持重做逻辑覆盖）
function check(el, choice) {
  const parent = el.parentNode;
  if (parent.classList.contains("answered")) return;

  const isMultiple = parent.getAttribute("data-multiple") === "true";
  const ans = parent.getAttribute("data-ans");
  const qId = parent.getAttribute("data-id");

  let list = isWrongMode
    ? wrongQuestions
    : isFavMode
      ? favQuestions
      : currentQuestions;

  if (isMultiple) {
    el.classList.toggle("active-choice");
  } else {
    parent.classList.add("answered");
    let isCorrect = choice === ans || el.innerText.trim() === ans;

    // 覆盖写入最新的痕迹记录
    userHistoryTracks[qId] = {
      status: isCorrect ? "correct" : "wrong",
      userChoice: [choice],
    };
    localStorage.setItem("quiz_user_tracks", JSON.stringify(userHistoryTracks));

    if (isCorrect) {
      el.classList.add("correct");
    } else {
      el.classList.add("wrong");
      addToWrongList(qId);
      Array.from(parent.children).forEach((li) => {
        let c = li.getAttribute("data-char");
        if (c === ans || li.innerText.trim() === ans)
          li.classList.add("correct");
      });
    }
    buildAnswerCardMatrix(list);
  }
}

// 多选题确认提交
function submitMultiple(btnObj) {
  const parent = btnObj.parentNode.querySelector(".options");
  if (parent.classList.contains("answered")) return;

  const qId = parent.getAttribute("data-id");
  let list = isWrongMode
    ? wrongQuestions
    : isFavMode
      ? favQuestions
      : currentQuestions;
  let qObj = list.find((item) => item.id === qId);
  if (!qObj) return;

  let userChoices = [];
  Array.from(parent.children).forEach((li) => {
    if (li.classList.contains("active-choice")) {
      userChoices.push(li.getAttribute("data-char"));
    }
  });
  userChoices.sort();
  const userAnsStr = userChoices.join("");
  const rightAnsStr = qObj.ans.split("").sort().join("");
  let isCorrect = userAnsStr === rightAnsStr;

  parent.classList.add("answered");
  btnObj.style.display = "none";

  userHistoryTracks[qId] = {
    status: isCorrect ? "correct" : "wrong",
    userChoice: userChoices,
  };
  localStorage.setItem("quiz_user_tracks", JSON.stringify(userHistoryTracks));

  Array.from(parent.children).forEach((li) => {
    li.classList.remove("active-choice");
    let itemChar = li.getAttribute("data-char");
    if (userChoices.includes(itemChar) && !qObj.ans.includes(itemChar)) {
      li.classList.add("wrong");
    } else if (qObj.ans.includes(itemChar)) {
      li.classList.add("correct");
    }
  });

  if (!isCorrect) addToWrongList(qId);
  buildAnswerCardMatrix(list);
}

// 导航按键
document.getElementById("prevBtn").addEventListener("click", () => {
  if (currentIndex > 0) {
    currentIndex--;
    refreshDisplay();
  }
});
document.getElementById("nextBtn").addEventListener("click", () => {
  let list = isWrongMode
    ? wrongQuestions
    : isFavMode
      ? favQuestions
      : currentQuestions;
  if (currentIndex < list.length - 1) {
    currentIndex++;
    refreshDisplay();
  }
});

// 键盘监听
document.addEventListener("keydown", (e) => {
  let list = isWrongMode
    ? wrongQuestions
    : isFavMode
      ? favQuestions
      : currentQuestions;
  if (list.length === 0) return;

  if (isSingleMode) {
    if (e.key === "ArrowLeft" && currentIndex > 0) {
      currentIndex--;
      refreshDisplay();
      return;
    } else if (e.key === "ArrowRight" && currentIndex < list.length - 1) {
      currentIndex++;
      refreshDisplay();
      return;
    }
  }

  if (isSingleMode) {
    const currentOptionsContainer = document.querySelector(".options");
    if (
      currentOptionsContainer &&
      !currentOptionsContainer.classList.contains("answered")
    ) {
      if (currentOptionsContainer.getAttribute("data-multiple") !== "true") {
        let keyUpper = e.key.toUpperCase();
        let targetIndex = LETTER_ARR.indexOf(keyUpper);
        if (targetIndex !== -1) {
          let targetLi = currentOptionsContainer.children[targetIndex];
          if (targetLi) targetLi.click();
        }
      }
    }
  }
});
